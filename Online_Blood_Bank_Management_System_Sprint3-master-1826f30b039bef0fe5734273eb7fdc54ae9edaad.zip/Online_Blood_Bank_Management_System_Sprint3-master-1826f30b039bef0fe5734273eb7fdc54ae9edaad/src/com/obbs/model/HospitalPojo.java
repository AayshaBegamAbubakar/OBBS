package com.obbs.model;

//This Pojo is used to store the Hospital data  during Operation. 
public class HospitalPojo {
	private int id;
	private String hospitalName;

	public String getHospitalName() {
		return hospitalName;
	}

	public void setId(int id) {
		this.id = id;
	}

	public void setHospitalName(String hospitalName) {
		this.hospitalName = hospitalName;
	}

	public int getId() {
		return id;
	}

}
