package com.obbs.junit;

import org.springframework.context.annotation.ComponentScan;

@ComponentScan(basePackages = "com.obbs")
public class TestBeanConfig {

}
